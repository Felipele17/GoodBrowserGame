from django.contrib.auth.views import LoginView
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import ListView, UpdateView, DetailView, DeleteView
from django.views.generic.edit import CreateView

from pag1.models import Cliente

class ClienteList(ListView):
    model = Cliente
    queryset = Cliente.objects.all()


class ClienteCreate(CreateView):
    model = Cliente
    fields = '__all__'
    success_url = reverse_lazy('pag1:list')


class ClienteUpdate(UpdateView):
    model = Cliente
    fields = '__all__'
    success_url = reverse_lazy('pag1:list')

class ClienteDetail(DetailView):
    queryset = Cliente.objects.all()


class ClienteDelete(DeleteView):
    queryset = Cliente.objects.all()
    success_url = reverse_lazy('pag1:list')



