from django import forms

from  pag1.models import Cliente

class ClienteForm(forms.ModelForm):
    class Meta:
        Model = Cliente
        fields = '__all__'