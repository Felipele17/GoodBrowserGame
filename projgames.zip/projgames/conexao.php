<?php
$servidor = "localhost:3306";
$usuario = "root";
$senha = "";
$dbname = "browser";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);