<?php

$nome = filter_input(INPUT_POST, 'nome', FILTER_SAANITIZE_STRING;)
$avaliar = filter_input(INPUT_POST, 'avaliar', FILTER_SAANITIZE_INT;)

echo "Nome: $nome <br>";
echo "Avaliação: $avaliar <br>";
?>